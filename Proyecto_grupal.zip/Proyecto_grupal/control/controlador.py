import pygame

class controlador:
    """
    clase encargada de gestionar los eventos de 
    entrada de los jugadores y traducirlos en acciones (movimiento y ataque) 
    sobre objetos jugador.
    """
    def __init__(self,jugador1,jugador2, ancho,alto):
        """
        inicializa el control con referencia a los jugadores y las 
        dimensiones de la pantalla para limitar el movimiento
        """
        self.jugador1 = jugador1
        self.jugador2 = jugador2
        self.ancho = ancho
        self.alto = alto
        
    def manejar_eventos(self):
        """
        lee el estado actual del teclado y ejecuta acciones :
        -movimiento de jugador1 con wasd
        - movimiento de jugador 2 con flechas
        - ataques cuando hay colision y se presionan las teclas de ataque
        
        """ 
        #obtiene un diccionario de teclas presionadas
        teclas = pygame.key.get_pressed()
        
        #movimiento de jugador1 (wasd)
   
            #control de movimiento
        if teclas[pygame.K_w]:
            self.jugador1.mover("arriba", 5 , self.ancho, self.alto)
        if teclas[pygame.K_s]:
            self.jugador1.mover("abajo", 5,self.ancho, self.alto)
        if teclas[pygame.K_a]:
            self.jugador1.mover("izquierda", 5,self.ancho, self.alto)
        if teclas[pygame.K_d]:
            self.jugador1.mover("derecha", 5,self.ancho, self.alto)
            
            
        if teclas[pygame.K_UP]:
            self.jugador2.mover("arriba", 5 , self.ancho, self.alto)
        if teclas[pygame.K_DOWN]:
            self.jugador2.mover("abajo", 5,self.ancho, self.alto)
        if teclas[pygame.K_LEFT]:
            self.jugador2.mover("izquierda", 5,self.ancho, self.alto)
        if teclas[pygame.K_RIGHT]:
            self.jugador2.mover("derecha", 5,self.ancho, self.alto)
            
            
        #manejo de ataques
        #jugador 1 ataca con barra espaciadora si esta colisionando
        #con jugador 2
            if teclas[pygame.K_SPACE]:
                if self.jugador1.colisiona_con(self.jugador2):
                    self.jugador1.atacar_a(self.jugador2)
                    
        #jugador 2 ataca con tecla enter si esta colisionando con 
        #jugador 1
            if teclas[pygame.K_RETURN]:
                if self.jugador2.colisiona_con(self.jugador1):
                    self.jugador2.atacar_a(self.jugador1)
                    