from .Personaje import Personaje
""" SubClase (Hija) de Personaje"""

class Orco(Personaje): 
    def __init__(self,nombre,vida,fuerza,defensa,nivel,experiencia,ira,resistencia,cura,porcentaje,fuerza_con_ira):
        super().__init__(nombre, vida, fuerza, defensa,nivel,experiencia,ultimo_atacante=None)
        """metodo que inicializa atributos propios de la subclase y llama a los atributos heredados de la superclase"""
        self.ira = 0.20 #furia tendra un valor de 20% definido
        self.cura= 0.15 #la cura siempre sera del 15%
        self.resistencia= resistencia
        self.porcentaje= None # none:para que solamente cuando contenga un valor se utilice y asi evitar recurrencia
        self.fuerza_con_ira= None

    def get_ira(self):
        """ Metodo para acceder por fuera de la subclase (Orco) que devuelve el atributo ira"""
        return self.ira
    def get_cura(self):
        """ Metodo para acceder por fuera de la subclase (Orco) que devuelve el atributo cura ."""
        return self.cura
    def get_resistencia(self):
        """ Metodo para acceder por fuera de la subclase (Orco) que devuelve el atributo resistencia."""
        return self.resistencia
    
    def mostrar_estado(self):
        """sobreescribe el metodo y agrega su propia implementacion para Orco """
        estados= super().mostrar_estado() 
        estado = f" Ira: {self.ira}, Resistencia: {self.resistencia}, Cura: {self.cura}, Porcentaje: {self.porcentaje}."
        return (estados + estado)
    
     
    def ataque(self, enemigo):
        """Método ataque sobreescrito.
        redefine el metodo con su propia implementacion si fue herido 
        anteriormente ataca con furia lo que incrementa su fuerza.
        sino ataca normalmente (metodo de la super clase)."""
       
        if self.fuerza_con_ira != None: #si fue herido antes ataca con una nueva fuerza
            
            fuerza_original= self.fuerza #almacenamos el valor de fuerza en una variable auxiliar
            self.fuerza = self.fuerza_con_ira 
            print(f"ataca con ira por ser herido. su valor de fuerza nueva es de: {self.fuerza}")
            super().ataque(enemigo) #contraataca con una nueva fuerza 
            self.fuerza = fuerza_original #la fuerza vuelve a la normalidad
            self.fuerza_con_ira = None #se reinicia la fuerza con ira.
            return
        else: # sino ataca normal.
            print( " ataque normal ")
            super().ataque(enemigo)
        
            return

    def recibir_danio(self, danio,atacante):
        """Método sobreescrito que recibe el danio y quien ataco.
        calcula el porcentaje de danio, reutiliza el metodo de la superclase y 
        envia al metodo ataque_con_ira el objeto de quien lo ataco y el danio que le hizo para que pueda 
        contraatacar."""
        
        self.porcentaje = (danio / 100)
        print(f"el valor que se envia a ataque con ira es de porcentaje: {self.porcentaje}, valor de danio: {danio}")
        super().recibir_danio(danio,atacante)
        if self.vida <= 0:
            self.porcentaje == None
        else:    
            self.ataque_con_ira(danio,atacante)  
        
    def ataque_con_ira(self,danio,atacante):
        """Metodo propio de la Subclase. recibe el danio y el atacante.
        que apartir del porcentaje que recibe aplicara dos tipos de ataques.
        si el porcentaje es bajo aumentara su fuerza, llama al metodo atacar para que implemente el ataque pero con nueva fuerza.
        y si el porcentaje de danio es alto,se cura aumentando la vida y resistencia.
        y si ninguna de estas condiciones se cumple no hace nada. 
        se asigna none a porcentaje para evitar concurrencia y asi evitar entrar en un bucle"""
        
        print(f"entro en ataque con ira, fuerza con ira es de: {self.fuerza_con_ira}")

        if self.porcentaje == (0.2) : #danio bajo
            self.fuerza_con_ira = danio+(danio * self.ira)+ self.fuerza # aumenta la fuerza por ira
            print(f"entro en el if, fuerza con ira es de: {self.fuerza_con_ira}")
            return self.ataque(atacante)
        if self.porcentaje > (0.2) : #danio alto
            self.vida = self.vida + (self.vida * self.cura) #se cura un porcentaje para seguir luchando
            self.resistencia = self.resistencia + (self.resistencia * self.cura) #aumenta su resistencia
            print ("activacion de: Luz Sagrada")
            print (f"Se curo un: {self.cura} le queda de vida: {self.vida}, y su resistencia aumenta : {self.resistencia}")
        else:
            return self.mostrar_estado()
        self.porcentaje = None
        
    def sigue_vivo(self):   
        """Metodo heredado."""                
        return super().sigue_vivo()
    
    def esta_muerto(self):
        """Metodo heredado."""
        return super().esta_muerto()
    def get_defensa(self):
        """Metodo heredado."""
        return super().get_defensa()
    def get_experiencia(self, numero):
        """Metodo heredado."""
        return super().get_experiencia(numero)
    def get_fuerza(self):
        """Metodo heredado."""
        return super().get_fuerza()
    def get_nivel(self):
        """Metodo heredado."""
        return super().get_nivel()
    def get_nombre(self):
        """Metodo heredado."""
        return super().get_nombre()
    def get_vida(self):
        """Metodo heredado."""
        return super().get_vida()
    
        
    