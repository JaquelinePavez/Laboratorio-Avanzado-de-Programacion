class Personaje:
    """Clase base de un personaje con atributos básicos y acciones."""
#-------------------METODO CONSTRUCTOR-------------------------------------------------------------#
    def __init__(self, nombre, vida, fuerza, defensa,nivel,experiencia,ultimo_atacante):
        """Inicializa un personaje con los valores recibidos por parámetros."""
        self.nombre = nombre 
        self.vida = vida    
        self.fuerza = fuerza
        self.defensa = defensa
        self.nivel = nivel
        self.experiencia = experiencia
        self.ultimo_atacante= ultimo_atacante
#----------------METODO------------------------------------------------------------------------------#        
    def ataque(self, enemigo):
        """Método que recibe un enemigo. 
        VERIFICA: que el atacante ni el enemigo este muerto. 
        CONTROLA: que no haya danio negativo.
        llama al metodo recibir_danio para aplicar el danio al enemigo (y envia quien es el que ataca)
        retorna el valor del danio"""
               
        if self.vida <= 0:  # Verifica si el que ataca está muerto
            print(f"{self.nombre} no puede atacar porque está muerto.")
            return  # No hace nada si el atacante está muerto 
        if enemigo.get_vida() <= 0:
            print (f"no se puede atacar al Enemigo {enemigo.get_nombre()} porque está muerto.")  
            return #No hace nada por que no puede atacar a alguien ya muerto.     
        danio = (self.fuerza - enemigo.get_defensa()) 
        enemigo.mostrar_estado()
        
        if danio < 1:  # Si el daño es menor a 1, forzamos un mínimo de 1 y asi se controla un posible numero negativo
            danio = 1
        print(f"{self.nombre} ataca a {enemigo.get_nombre()} causando {danio} de daño.")
        self.ultimo_atacante =  self #para guardar el ultimo atacante y asi poder utilizarlo en las subclases. modificacion extra
        enemigo.recibir_danio(danio,self.ultimo_atacante)
        return danio

    def recibir_danio(self, danio,atacante):
        """Método que recibe el atacante y el danio para poder descontar la vida ."""
        print(f"{self.nombre} recibe {danio} de daño.") #PARA CONTROLAR QUE EL RECIBA EL DANIO
        self.vida = self.vida - danio  # Aplica el daño correctamente
        if self.vida <= 0:  # Evita valores negativos
            self.esta_muerto()

    def sigue_vivo(self):
        """Verifica si el personaje sigue vivo. retorna un mensaje con 
        la cantidad de vida si esta vivo todavia. sino llama al metodo esta muerto"""
        if self.vida > 0:
            supervivencia = f"{self.nombre} sigue vivo con {self.vida} de vida."
            print(f"{self.nombre} sigue vivo con {self.vida} de vida.")
            return supervivencia
        else:
            self.esta_muerto()

    def esta_muerto(self):
        """Método que maneja la muerte del personaje. retorna el nombre del personaje que murio."""
        if self.vida <= 0: # si le quedo valores negativos en la vida , lo iguala a 0 y lo declara muerto
            self.vida = 0  # Solo iguala a 0 si es negativa
            print(f"{self.nombre} ha muerto.")
            supervivencia = f"{self.nombre} ha muerto."
            return supervivencia


    def mostrar_estado(self):
        """Muestra el estado del personaje """
        estado = f"{self.nombre} - Vida: {self.vida}, Fuerza: {self.fuerza}, Defensa: {self.defensa}, Experiencia: {self.experiencia}, Nivel: {self.nivel} "
        
        return (estado)
    
    def get_vida(self):
        """metodo que retorna el atributo vida para que pueda ser accedido por fuera de la clase"""
        return self.vida
    
    def get_fuerza(self):
        """metodo que retorna el atributo fuerza para que pueda ser accedido por fuera de la clase"""
        return self.fuerza
    
    def get_defensa(self):
        """metodo que retorna el atributo defensa para que pueda ser accedido por fuera de la clase"""
        return self.defensa
    
    def get_nombre(self):
        """metodo que retorna el atributo nombre para que pueda ser accedido por fuera de la clase"""
        return self.nombre
    
    def get_experiencia(self,numero):
        """metodo que recibe un numero y retorna el atributo experiencia para que pueda ser accedido por fuera de la clase.
        Ademas, verifica que una vez haya llegado su valor a 100 se inicialice en 0  y invoque al metodo subir_nivel
        para incrementar su nivel"""
        self.experiencia += numero #itera el for del test 1 en 1 hasta llegar a 100
        if (self.experiencia == 100 ):           
            self.experiencia = 0 # lo inicializa a 0 
            self.subir_nivel()
           
    def subir_nivel(self):
        """metodo que increma en 1 su valor cada vez que la experiencia llegue a 100"""
        self.nivel += 1
        return self.nivel
            
    def get_nivel(self):
        """metodo que retorna el atributo nivel. """
        return self.nivel
    


       
