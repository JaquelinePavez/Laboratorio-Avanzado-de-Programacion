from .Personaje import Personaje
""" SUBCLASE elfo que hereda de la SUPERCLASE Personaje"""

class Elfo(Personaje):
    def __init__(self, nombre, vida, fuerza, defensa, nivel, experiencia, precision=2, sigilo=False):
        super().__init__(nombre, vida, fuerza, defensa, nivel, experiencia,ultimo_atacante=None)
        """ Inicializa los atributos propios de la subclase Elfo , reutiliza el constructor de la superclase"""
        self.precision = precision # valor establecido para ser calculado 
        self.sigilo = sigilo              
                 

    def ataque(self, enemigo):
        """Sobrescribe el método de ataque de la clase base. y da su propia implementacion.
        recibe por parametros enemigo y duplica la fuerza por precision, para causar mayor danio"""
        
        print(f"{self.nombre} ataca con precisión aumentada.")
        daño_original = self.fuerza
        self.fuerza *= self.precision  # Fuerza doble por precisión
        super().ataque(enemigo)
        self.fuerza = daño_original  # Restaurar fuerza original

    def ataque_elfico(self, enemigo):
        """ Metodo propio de la subclase, recibe por parametro enemigo.
        Ataque que controla si tiene sigilo activado(invisible) realiza dos golpes rapidos(el enemigo no se puede defender).
        sino realiza un ataque con precision(llama al metodo sobreescrito atacar).
        """
        if self.sigilo == False:
            print(f"{self.nombre} intenta un ataque élfico, pero no está en sigilo.")
            return self.ataque(enemigo)
        if self.sigilo == True:
            print(f"{self.nombre} realiza un ataque élfico invisible a {enemigo.get_nombre()}.")
            print("Primer golpe veloz.")
            enemigo.recibir_danio(self.fuerza,self)
            print("Segundo golpe veloz.")
            enemigo.recibir_danio(self.fuerza,self)

    def mostrar_estado(self):
        """Metodo heredado. retorna el estado de atributos de la super clase y de la clase base."""   
        estado_principal = super().mostrar_estado()
        estado_clase= (f" Precision: {self.precision}, Sigilo: {self.sigilo}.")
        return estado_principal+estado_clase
    
    
    def recibir_danio(self, danio, atacante):
        """Metodo heredado."""   
        return super().recibir_danio(danio, atacante)
    
    def sigue_vivo(self):
        """Metodo heredado."""   
        return super().sigue_vivo()
    
    def esta_muerto(self):
        """Metodo heredado."""   
        return super().esta_muerto()
    
    def get_precision(self):
        """ Metodo propio. retorna atributo precision."""
        return self.precision
    
    def get_sigilo(self):
        """ Metodo propio. retorna atributo sigilo. """
        return self.sigilo
        
    def get_nivel(self):
        """Metodo heredado."""   
        return super().get_nivel()
    
    def get_experiencia(self, numero):
        """Metodo heredado."""   
        return super().get_experiencia(numero)
    
    def subir_nivel(self):
        """Metodo heredado."""   
        return super().subir_nivel()
    
    def get_nombre(self):
        return super().get_nombre()
    
    def get_vida(self):
        return super().get_vida()
    
    def get_defensa(self):
        return super().get_defensa()
    
    def get_fuerza(self):
        return super().get_fuerza()
    
    

    