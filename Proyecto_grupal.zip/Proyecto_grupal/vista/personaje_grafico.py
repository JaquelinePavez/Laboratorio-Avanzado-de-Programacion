#importamos las bibliotecas necesarias
import pygame #libreria para juegos 2d en python
import sys #permite salir del programa correctamente.


class personajeGrafico:
    """Representa un personaje grafico en pantalla.
        Atributos:
            rect: rectangulo que define su posicion y tamanio
            color: color con el que se dibuja
        
    """
    def __init__(self,x,y,color,modelo):
        """
        inicializa la posicion y color del personaje.
        x, y : coordenadas iniciales.
        color: tupla RBG.
        """
        self.rect = pygame.Rect(x,y,60,60)
        self.color = color
        self.modelo = modelo
        
        
    def mover(self,direccion,cantidad, ANCHO, ALTO):
        """
        mueve el personaje en una direccion dada.
        direccion: arriba, abajo,izquierda o derecha.
        cantidad: desplazamiento en pixeles.
        ANCHO, ALTO: limites de la pantalla para evitar salir.
        """
        if direccion == "arriba":
            self.rect.y -= cantidad
        elif direccion == "abajo":
            self.rect.y += cantidad
        elif direccion == "izquierda":
            self.rect.x -= cantidad
        elif direccion == "derecha":
            self.rect.x += cantidad
            
        if self.rect.left < 0 :
            self.rect.left = 0
        if self.rect.right > ANCHO:
            self.rect.right = ANCHO
        if self.rect.top < 0 :
            self.rect.top = 0 
        if self.rect.bottom > ALTO:
            self.rect.bottom = ALTO
    
    
    def dibujar(self,pantalla):
        """
        dibuja el persinaje sobre la superficie dada.
        pantalla: superficie donde se dibuja.
        """
        pygame.draw.rect(pantalla,self.color,self.rect)
    
    def colisiona_con(self, otro):
        """
        detecta si colisiona con otro personaje.
        otro: otro personajegrafico.
        devuelve: true si colisionan.
        """
        return self.rect.colliderect(otro.rect)
    
    def atacar_a(self, otro):
        """
        ataca otro personaje.
        otro: otro personajegrafico
        """
        self.modelo.atacar(otro.modelo)